# في مجرّة ليلى — Android starter app

واجهة أولية أصلية لأندرويد باستخدام Kotlin وJetpack Compose، بهوية كحلية وذهبية واتجاه عربي RTL.

## ما الذي يعمل في هذه النسخة؟
- قارئ عربي مع حجم خط قابل للتعديل.
- فهرس من 25 فصلًا.
- التنقل بين الصفحات وتأثير انتقال بسيط بين الفصول.
- حفظ موضع القراءة وحجم الخط وعلامة المرجع محليًا باستخدام SharedPreferences.
- زر للموسيقى الهادئة كعنصر واجهة أولي.

## ملاحظة حول الموسيقى
زر الموسيقى في هذه النسخة يغيّر حالة الواجهة فقط؛ لم يُضمَّن ملف صوتي مرخّص. لإضافة تشغيل فعلي، ضع ملفًا مرخّصًا مثل `ambient.mp3` داخل `app/src/main/res/raw/` ثم اربطه بـ MediaPlayer أو ExoPlayer.

## فتح المشروع
1. فك ضغط الملف.
2. افتح المجلد في Android Studio حديث.
3. اسمح بمزامنة Gradle.
4. شغّل التطبيق على محاكي أو هاتف أندرويد.

## مهم
هذه نسخة تأسيسية قابلة للتطوير، وليست ملف APK جاهزًا للتثبيت. النصوص الحالية مسودات تجريبية وليست الفصول النهائية للرواية.

## Build APK from a phone using GitHub Actions

This ZIP includes `.github/workflows/build-apk.yml` to build a debug APK in GitHub's cloud runner.

1. Create a repository on GitHub from your phone and upload the **contents** of this project (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Layla APK** and tap **Run workflow** (or push to `main`).
4. When the run completes successfully, open that run, find **Artifacts**, and download `Fi-Majarrat-Layla-APK`.
5. Extract the downloaded artifact ZIP; install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

The workflow builds a debug APK, suitable for personal testing, not a Play Store release.
