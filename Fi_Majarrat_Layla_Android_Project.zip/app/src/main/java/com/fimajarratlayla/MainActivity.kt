package com.fimajarratlayla

import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

private val Night = Color(0xFF10152D)
private val Night2 = Color(0xFF1A2041)
private val Gold = Color(0xFFE7C18A)
private val Paper = Color(0xFFF4EBDD)
private val Ink = Color(0xFF30263A)
private val Muted = Color(0xFFB9B2C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LaylaReader(this) }
    }
}

private data class Chapter(val title: String, val excerpt: String)
private val chapters = listOf(
    Chapter("تلك الفتاة التي تشبه النجوم", "في كل مرة أرى فيها اسمها، أشعر أن الكون يتوقف ليصغي. ليلى ليست مجرد فتاة؛ بل هي الضوء الذي ينعكس في داخلي حتى في أكثر أيامي عتمة."),
    Chapter("رسالة من آخر المجرّة", "وصلت الرسالة عند منتصف الليل، بلا عنوان ولا توقيع. كان فيها سطر واحد: بعض النجوم لا ينبغي أن تستيقظ."),
    Chapter("خريطة لا تشبه السماء", "على الورقة القديمة، كانت النجوم تتحرك كلما اقتربت ليلى منها، كأن الخريطة تعرف اسمها قبل أن تعرفه هي."),
    Chapter("حين يصمت الضوء", "لم يكن الصمت فراغًا. كان شيئًا يراقبهما من وراء زجاج الليل، ينتظر أن يخطئ أحدهما في نطق الحقيقة."),
    Chapter("النافذة السابعة", "في النافذة السابعة، رأت ليلى مدينة لم تظهر في أي سجل فلكي، وسمعت صوتًا يناديها من جهة لا وجود لها."),
    Chapter("أثر على حافة الزمن", "وجدت أثرًا صغيرًا على ساعة جدّها، علامة تشبه مدارًا حول نجم ميت. وحين لمسته، قفزت عقارب الساعة إلى الوراء."),
    Chapter("وعد تحت المطر النجمي", "تحت شهبٍ تعبر السماء، وعدها ألا يترك السؤال بينهما يتحول إلى جدار. لم يكن يعرف أن الوعد سيختبره قبل الفجر."),
    Chapter("مدينة وراء القمر", "كانت المدينة تنام خلف القمر، مخفيةً عن العيون العادية. أبوابها لا تُفتح بالمفاتيح، بل بالذكريات التي نحاول نسيانها."),
    Chapter("اسم لا يُقال", "كلما اقتربت ليلى من السر، صار اسمها أثقل على اللسان، كأن نطقه سيوقظ شيئًا أقدم من النجوم."),
    Chapter("الضيف الذي لا ظلّ له", "دخل الغريب دون أن يفتح الباب، وجلس قرب النافذة. لم يكن له ظل، لكنه عرف كل ما حدث في الغرفة."),
    Chapter("نبض المجرّة", "كان النبض خافتًا في البداية، مثل قلب نائم. ثم صار يهزّ الأفق، وكأن مجرّة كاملة تحاول تحذيرهما."),
    Chapter("أرشيف الأحلام", "في الأرشيف، لم تكن الكتب تحفظ التاريخ، بل الأحلام التي تخلّى عنها أصحابها كي ينجوا."),
    Chapter("نصف حقيقة", "أخبرها بالحقيقة التي استطاع قولها، وأخفى الأخرى. أحيانًا تكون أنصاف الحقائق أكثر خطورة من الكذب."),
    Chapter("على الجانب الآخر", "لم يكن الجانب الآخر مكانًا، بل اختيارًا. خطوة واحدة كانت كافية لتغيّر معنى كل شيء."),
    Chapter("قلب من غبار النجوم", "في الصندوق قلب صغير مصنوع من غبار النجوم، دافئ على نحو مستحيل، ويحمل نقشًا باسم ليلى."),
    Chapter("الخيانة البيضاء", "لم يأتِ الخطر في هيئة عدو. جاء بصوت مألوف، وبيدٍ امتدت لتساعدهما حين كانا في أمسّ الحاجة."),
    Chapter("الممر الذي يتذكّر", "كل خطوة في الممر أعادت ذكرى لم يعشها أحد منهما، ومع ذلك عرفا أن الذكريات تخصّهما."),
    Chapter("قبل انطفاء السماء", "بدأت النجوم تختفي واحدة تلو الأخرى. لم يكن أمامهما سوى ليلة واحدة لفهم ما الذي يربط ليلى بمصير المجرّة."),
    Chapter("الثمن", "قالت ليلى إن النجاة لا تستحق أن يفقد المرء نفسه. لكن الكون لم يكن يعرض عليهما خيارًا بلا ثمن."),
    Chapter("خارج المدار", "للمرة الأولى، اتخذا قرارًا لا تتنبأ به الخريطة. ارتجفت السماء، ثم انفتح طريق لم يكن موجودًا."),
    Chapter("ما تركه الأجداد", "في رسالة أخيرة، اكتشفا أن السر لم يبدأ معهما، وأن كل جيل كان يحرس جزءًا من الحقيقة."),
    Chapter("مجرّة من زجاج", "بدت المجرّة كقبة زجاجية هائلة، جميلة وهشّة، وكل شق فيها كان يعكس احتمالًا لمستقبل مختلف."),
    Chapter("حين اختارت ليلى", "لم تنتظر ليلى أن يختار عنها أحد. رفعت رأسها نحو الضوء، واتخذت القرار الذي خاف الجميع من تسميته."),
    Chapter("النجمة الأخيرة", "لم تكن النجمة الأخيرة أقوى من سواها؛ كانت فقط الوحيدة التي بقيت مضيئة حين نسي الجميع كيف ينظرون إلى السماء."),
    Chapter("في مجرّة ليلى", "حين عاد الليل إلى هدوئه، لم تعد السماء كما كانت. بعض الأسرار انتهى، وبعضها صار بداية حكاية أخرى.")
)

@Composable
fun LaylaReader(context: Context) {
    val prefs = remember { context.getSharedPreferences("layla_reader", Context.MODE_PRIVATE) }
    var chapterIndex by remember { mutableIntStateOf(prefs.getInt("chapter", 0).coerceIn(0, 24)) }
    var pageIndex by remember { mutableIntStateOf(prefs.getInt("page", 1).coerceIn(1, 200)) }
    var saved by remember { mutableStateOf(prefs.getBoolean("bookmarked", false)) }
    var showChapters by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var musicOn by remember { mutableStateOf(false) }
    var fontSize by remember { mutableFloatStateOf(prefs.getFloat("fontSize", 23f)) }

    fun persist() {
        prefs.edit().putInt("chapter", chapterIndex).putInt("page", pageIndex)
            .putBoolean("bookmarked", saved).putFloat("fontSize", fontSize).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Night, surface = Night2,
        onPrimary = Night, onBackground = Paper, onSurface = Paper
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Night, Night2, Color(0xFF24213C))))) {
            Column(Modifier.fillMaxSize()) {
                // Hero header
                Box(
                    Modifier.fillMaxWidth().weight(0.31f).padding(horizontal = 20.dp, vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Text("✦", color = Gold, fontSize = 24.sp)
                            Spacer(Modifier.width(10.dp))
                            Text("في مجرّة ليلى", color = Paper, fontSize = 16.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.width(10.dp))
                            Text("✦", color = Gold, fontSize = 24.sp)
                        }
                        Spacer(Modifier.height(15.dp))
                        Text("في مجرّة", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Light)
                        Text("ليلى", color = Gold, fontSize = 62.sp, fontWeight = FontWeight.Bold, lineHeight = 66.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("رواية عن الأسرار التي تضيء العتمة", color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            AssistChip(onClick = { showChapters = true }, label = { Text("الفصول") }, leadingIcon = { Icon(Icons.Default.List, null, tint = Gold) })
                            AssistChip(onClick = { musicOn = !musicOn }, label = { Text(if (musicOn) "إيقاف الموسيقى" else "موسيقى هادئة") }, leadingIcon = { Icon(if (musicOn) Icons.Default.Pause else Icons.Default.Headphones, null, tint = Gold) })
                        }
                    }
                    Text("☾", modifier = Modifier.align(Alignment.TopEnd), color = Gold.copy(alpha = .75f), fontSize = 27.sp)
                }

                // Reading paper
                Column(
                    Modifier.fillMaxWidth().weight(0.69f)
                        .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                        .background(Brush.verticalGradient(listOf(Paper, Color(0xFFE8D9C5))))
                        .padding(horizontal = 22.dp, vertical = 17.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        IconButton(onClick = { saved = !saved; persist() }) {
                            Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "حفظ علامة", tint = Color(0xFF7A4D35))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("الفصل ${chapterIndex + 1} من 25", color = Ink, fontSize = 13.sp)
                            Text(chapters[chapterIndex].title, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "إعدادات القراءة", tint = Color(0xFF7A4D35))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.weight(1f))
                        Text("────── ✦ ──────", color = Color(0xFF9A684A), fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                    }
                    AnimatedContent(
                        targetState = chapterIndex,
                        transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(120)) },
                        label = "chapterTransition",
                        modifier = Modifier.weight(1f)
                    ) { idx ->
                        Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                            Text(
                                chapters[idx].excerpt + "\n\n" +
                                "كانت ليلى تعرف أن في السماء أبوابًا لا تُفتح إلا حين يجرؤ أحدهم على طرح السؤال الصحيح. لم تكن تعرف بعد أن الإجابة ستغيّر كل ما اعتقدته عن نفسها وعن النجوم.",
                                color = Ink, fontSize = fontSize.sp, lineHeight = (fontSize * 1.75f).sp,
                                textAlign = TextAlign.Justify
                            )
                            Spacer(Modifier.height(14.dp))
                            Text("✧  ✧  ✧", color = Color(0xFF9A684A), fontSize = 17.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Slider(
                        value = pageIndex.toFloat(), onValueChange = { pageIndex = it.toInt().coerceIn(1, 200) },
                        onValueChangeFinished = { persist() }, valueRange = 1f..200f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF7A4D35), activeTrackColor = Color(0xFF9A684A), inactiveTrackColor = Color(0xFFCDB9A1))
                    )
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            if (pageIndex > 1) pageIndex-- else if (chapterIndex > 0) { chapterIndex--; pageIndex = 1 }
                            persist()
                        }) { Icon(Icons.Default.ChevronLeft, "الصفحة السابقة", tint = Ink) }
                        Spacer(Modifier.weight(1f))
                        Text("$pageIndex / 200", color = Ink, fontSize = 14.sp)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = {
                            if (pageIndex < 200) pageIndex++ else if (chapterIndex < 24) { chapterIndex++; pageIndex = 1 }
                            persist()
                        }) { Icon(Icons.Default.ChevronRight, "الصفحة التالية", tint = Ink) }
                    }
                }
            }
        }
    }

    if (showChapters) {
        AlertDialog(
            onDismissRequest = { showChapters = false },
            title = { Text("فهرس الرواية", textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()) },
            text = {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    itemsIndexed(chapters) { index, chapter ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                .clickable { chapterIndex = index; pageIndex = (index * 8 + 1).coerceAtMost(200); persist(); showChapters = false }
                                .padding(vertical = 11.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${index + 1}", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
                            Text(chapter.title, color = Paper, fontSize = 14.sp)
                        }
                        HorizontalDivider(color = Muted.copy(alpha = .18f))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showChapters = false }) { Text("إغلاق") } },
            containerColor = Night2, titleContentColor = Paper, textContentColor = Paper
        )
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("إعدادات القراءة") },
            text = {
                Column {
                    Text("حجم الخط: ${fontSize.toInt()}")
                    Slider(value = fontSize, onValueChange = { fontSize = it }, valueRange = 18f..30f,
                        colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold))
                    Text("يُحفظ حجم الخط وموضع القراءة على هذا الجهاز.", fontSize = 12.sp, color = Muted)
                }
            },
            confirmButton = {
                TextButton(onClick = { persist(); showSettings = false }) { Text("تم") }
            },
            containerColor = Night2, titleContentColor = Paper, textContentColor = Paper
        )
    }
}
